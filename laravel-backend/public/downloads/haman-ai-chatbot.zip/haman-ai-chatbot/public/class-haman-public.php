<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Haman_Public {
    public function enqueue_assets(): void {
        if (get_option('haman_enabled','1') !== '1') return;
        $chatbot_id = get_option('haman_chatbot_id','');
        if (empty($chatbot_id)) return;

        wp_enqueue_script(
            'haman-widget',
            HAMAN_PLUGIN_URL . 'public/js/haman-widget.js',
            [],
            HAMAN_VERSION,
            true
        );

        // No wp_enqueue_style(): the widget's stylesheet is loaded only
        // inside its own Shadow DOM root (haman-widget.js, CFG.cssUrl) —
        // that is what isolates it from the theme. It used to be enqueued
        // on every page as well, which loaded the same file twice and put
        // it into the document for cache/minify plugins to rewrite, for no
        // effect: nothing outside the shadow root uses it.
        wp_localize_script('haman-widget', 'HamanWidgetConfig', $this->build_config($chatbot_id));
    }

    /**
     * Performance plugins (WP Rocket, Autoptimize, Perfmatters,
     * FlyingPress, ...) defer/lazy-load third-party scripts and minify or
     * combine stylesheets by default — entirely reasonable for a typical
     * static asset, but this widget boots itself and builds its own Shadow
     * DOM the instant it runs, and any delay or rewrite that changes its
     * CSS even slightly produces exactly the "looks right at first, then
     * falls apart" symptom a site owner has no way to diagnose themselves.
     * WP Rocket's "Delay JavaScript Execution" in particular holds the
     * script until a real user interaction (click/scroll/touch), so the
     * widget simply never initializes until something else on the page
     * happens to trigger it.
     *
     * Confirmed necessary on a real customer's live site running WP Rocket
     * (2026-10-12) — reported as "pretty then breaks", traced to the
     * script tag arriving as type="text/rocketlazyloadscript" with the
     * real URL stashed in data-rocket-src, and the CSS served through WP
     * Rocket's own minify/cache proxy. Excluding by handle/URL here fixes
     * this for every site running these plugins, not just the one that
     * happened to report it, without asking any site owner to go find a
     * settings page and guess what to type into it.
     */
    public function exclude_from_optimization(): void {
        $js_path  = 'haman-ai-chatbot/public/js/haman-widget.js';
        $css_path = 'haman-ai-chatbot/public/css/haman-widget.css';

        // WP Rocket: each of these is a distinct opt-out list — "delay
        // execution" and "load deferred" are two different WP Rocket
        // features (the live site above had the script tagged for both),
        // and minify/combine for JS and CSS are separate from either.
        add_filter('rocket_delay_js_exclusions', fn (array $e) => array_merge($e, [$js_path]));
        add_filter('rocket_exclude_defer_js',    fn (array $e) => array_merge($e, [$js_path]));
        add_filter('rocket_exclude_js',          fn (array $e) => array_merge($e, [$js_path]));
        add_filter('rocket_exclude_css',         fn (array $e) => array_merge($e, [$css_path]));

        // Autoptimize, Perfmatters, FlyingPress and others honor this
        // de-facto data-no-optimize attribute directly on the tag;
        // data-cfasync="false" is the equivalent Cloudflare Rocket Loader
        // respects (an unrelated "Rocket" from WP Rocket, same idea).
        add_filter('script_loader_tag', [$this, 'addNoOptimizeAttribute'], 10, 2);
        add_filter('style_loader_tag',  [$this, 'addNoOptimizeAttribute'], 10, 2);
    }

    public function addNoOptimizeAttribute(string $tag, string $handle): string {
        if ($handle !== 'haman-widget' || str_contains($tag, 'data-no-optimize')) return $tag;
        return preg_replace('/^<(script|link)\b/', '<$1 data-no-optimize="1" data-cfasync="false"', $tag, 1);
    }

    private function build_config(string $chatbot_id): array {
        $api_url = rtrim(get_option('haman_api_url', HAMAN_API_BASE), '/');

        // add_to_cart tool (doc-04 "Add to cart") — the widget runs on this
        // same domain as the shop, so it can call WooCommerce's own Store
        // API directly with the browser's own cookies, no cart token or
        // buyer-identity problem at all. The nonce is generated here, at
        // page-render time, and handed to the widget in this same config —
        // NonceUtils::create_nonce() is the Store API's own documented way
        // to do this for a server-rendered page, specifically so a script
        // like this one never needs an extra round trip just to get one.
        // Nonces are tied to the current session and expire (haman-
        // widget.js refreshes and retries once if this one has gone stale
        // by the time the add actually fires — which happens immediately
        // once the model calls the tool, not on a later click; see
        // autoAddToCart() in haman-widget.js).
        $store_api_nonce = '';
        $cart_url = '';
        $checkout_url = '';
        $store_api_url = '';
        if ( class_exists( 'WooCommerce' ) ) {
            if ( class_exists( '\Automattic\WooCommerce\StoreApi\Utilities\NonceUtils' ) ) {
                $store_api_nonce = \Automattic\WooCommerce\StoreApi\Utilities\NonceUtils::create_nonce();
            } else {
                // Older WooCommerce without Blocks/Store API installed —
                // this nonce action name is what the Store API itself
                // verifies against, but if the API endpoints below 404
                // (Store API not registered at all), haman-widget.js falls
                // back to the classic ?add-to-cart= link either way.
                $store_api_nonce = wp_create_nonce( 'wc_store_api' );
            }
            $cart_url     = wc_get_cart_url();
            $checkout_url = wc_get_checkout_url();
            $store_api_url = rest_url( 'wc/store/v1/' );
        }

        // Content/appearance settings (welcome message, chat title, AI
        // name, quick questions, avatar, color, position) are no longer
        // editable locally at all — the customer portal (WidgetSettings
        // page) is the single source of truth for them now; see
        // ChatController::mergedWidgetConfig() / App\Support\WidgetDefaults
        // on the backend. What follows is a generic, hardcoded first-paint
        // fallback only, replaced within a fraction of a second by the real
        // values once /chat/session responds (applyWidgetConfig() in
        // haman-widget.js) — a chatbot configured for English reads
        // English even on a Persian WP site, and vice versa, since that's
        // driven by the chatbot's own `language` column, not get_locale().
        $is_fa = strpos(get_locale(), 'fa') === 0;
        $dir   = $is_fa ? 'rtl' : 'ltr';
        $l10n_defaults = $is_fa ? [
            'sendButtonLabel'        => 'ارسال',
            'placeholder'            => 'پیام خود را بنویسید...',
            'unavailableMessage'     => 'چت‌بات در حال حاضر در دسترس نیست. لطفاً بعداً دوباره تلاش کنید.',
            'genericErrorMessage'    => 'خطایی رخ داد.',
            'connectionErrorMessage' => 'ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید.',
            'checkingAvailabilityMessage' => 'در حال بررسی موجودی...',
        ] : [
            'sendButtonLabel'        => 'Send',
            'placeholder'            => 'Write your message...',
            'unavailableMessage'     => "The chatbot isn't available right now. Please try again later.",
            'genericErrorMessage'    => 'Something went wrong.',
            'connectionErrorMessage' => 'Could not connect to the server. Please try again.',
            'checkingAvailabilityMessage' => 'Checking availability...',
        ];
        $i18n = $is_fa ? [
            'dialogLabel'          => 'گفتگو با پشتیبانی هوشمند',
            'closeLabel'           => 'بستن گفتگو',
            'openLabel'            => 'باز کردن گفتگو',
            'copyLabel'            => 'کپی پیام',
            'copiedLabel'          => 'کپی شد',
            'scrollToBottomLabel'  => 'رفتن به پایین',
            // Product cards / comparison table (recommend_products,
            // compare_products tools) — see renderProductCards()/
            // renderCompareTable() in haman-widget.js.
            'inStockLabel'         => 'موجود',
            'outOfStockLabel'      => 'ناموجود',
            'viewProductLabel'     => 'مشاهده محصول',
            'showMoreProductsLabel' => 'نمایش :count محصول دیگر',
            // build_cart_url tool — see renderCartLinks() in haman-widget.js.
            'addToCartLabel'       => 'افزودن به سبد خرید',
            // add_to_cart tool (Store API, same-origin) — fires
            // immediately, no click. See renderAddToCartIntent()/
            // autoAddToCart() in haman-widget.js. itemsInCartLabel and
            // orderTotalLabel (below) are reused together for the real
            // confirmed-outcome message once the add completes.
            'addingToCartLabel'    => 'در حال افزودن...',
            'itemsInCartLabel'     => ':count کالا در سبد شما',
            'viewCartLabel'        => 'مشاهده سبد خرید',
            'checkoutLabel'        => 'تسویه‌حساب',
            'chooseVariantLabel'   => 'لطفاً ابتدا سایز/رنگ مورد نظر را مشخص کنید.',
            'outOfStockAddErrorLabel' => 'متأسفانه این کالا دیگر موجود نیست.',
            'genericAddErrorLabel' => 'افزودن به سبد خرید ممکن نشد. لطفاً دوباره تلاش کنید.',
            // create_payment_link tool — see renderPaymentLinkPreview()/
            // handleConfirmPaymentClick() in haman-widget.js.
            'orderTotalLabel'       => 'مبلغ کل',
            'confirmAndPayLabel'    => 'تأیید و پرداخت',
            'creatingOrderLabel'    => 'در حال ساخت سفارش...',
            'payNowLabel'           => 'پرداخت',
            'paymentLinkErrorLabel' => 'ساخت لینک پرداخت ممکن نشد. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.',
            'sendCodeToLabel'       => 'ارسال کد تأیید به',
            'sendCodeLabel'         => 'ارسال کد',
            'sendingCodeLabel'      => 'در حال ارسال...',
            'enterCodeLabel'        => 'کد پیامک‌شده را وارد کنید:',
            'verifyCodeLabel'       => 'تأیید',
            'verifyingCodeLabel'    => 'در حال بررسی...',
            'codeIncorrectLabel'    => 'کد واردشده درست نیست یا منقضی شده. دوباره تلاش کنید.',
            'noOrdersFoundLabel'    => 'با این شماره سفارشی در این فروشگاه پیدا نشد.',
            'orderStatusErrorLabel' => 'الان امکان پیگیری سفارش نیست. لطفاً بعداً دوباره تلاش کنید.',
            'trackingLabel'         => 'کد رهگیری',
            'orderStatuses'         => [
                'pending'    => 'در انتظار پرداخت',
                'processing' => 'در حال پردازش',
                'on-hold'    => 'در انتظار',
                'completed'  => 'تحویل‌شده',
                'cancelled'  => 'لغوشده',
                'refunded'   => 'بازگشت‌وجه',
                'failed'     => 'ناموفق',
            ],
        ] : [
            'dialogLabel'          => 'Chat with AI assistant',
            'closeLabel'           => 'Close chat',
            'openLabel'            => 'Open chat',
            'copyLabel'            => 'Copy message',
            'copiedLabel'          => 'Copied',
            'scrollToBottomLabel'  => 'Scroll to bottom',
            'inStockLabel'         => 'In stock',
            'outOfStockLabel'      => 'Out of stock',
            'viewProductLabel'     => 'View product',
            'showMoreProductsLabel' => 'Show :count more',
            'addToCartLabel'       => 'Add to cart',
            'addingToCartLabel'    => 'Adding...',
            'itemsInCartLabel'     => ':count item(s) in your cart',
            'viewCartLabel'        => 'View cart',
            'checkoutLabel'        => 'Checkout',
            'chooseVariantLabel'   => 'Please choose a size/color first.',
            'outOfStockAddErrorLabel' => 'Sorry, this item is no longer in stock.',
            'genericAddErrorLabel' => "Couldn't add this to your cart. Please try again.",
            'orderTotalLabel'       => 'Total',
            'confirmAndPayLabel'    => 'Confirm & Pay',
            'creatingOrderLabel'    => 'Creating order...',
            'payNowLabel'           => 'Pay now',
            'paymentLinkErrorLabel' => "Couldn't create a payment link. Please try again or contact support.",
            'sendCodeToLabel'       => 'Send a verification code to',
            'sendCodeLabel'         => 'Send code',
            'sendingCodeLabel'      => 'Sending...',
            'enterCodeLabel'        => 'Enter the code we texted you:',
            'verifyCodeLabel'       => 'Verify',
            'verifyingCodeLabel'    => 'Checking...',
            'codeIncorrectLabel'    => 'That code is incorrect or has expired. Please try again.',
            'noOrdersFoundLabel'    => 'No orders were found for that number at this store.',
            'orderStatusErrorLabel' => "Order tracking isn't available right now. Please try again later.",
            'trackingLabel'         => 'Tracking code',
            'orderStatuses'         => [
                'pending'    => 'Awaiting payment',
                'processing' => 'Processing',
                'on-hold'    => 'On hold',
                'completed'  => 'Completed',
                'cancelled'  => 'Cancelled',
                'refunded'   => 'Refunded',
                'failed'     => 'Failed',
            ],
        ];

        return [
            'chatbotId'   => $chatbot_id,
            'apiUrl'      => $api_url,
            // Versioned, like the enqueued script: without ?ver= a browser
            // kept the previous release's stylesheet after a plugin update.
            'cssUrl'      => HAMAN_PLUGIN_URL . 'public/css/haman-widget.css?ver=' . rawurlencode( HAMAN_VERSION ),
            'dir'         => $dir,
            // Every field below this point is a generic first-paint-only
            // fallback — see the comment above. Must not derive `position`
            // from `$dir`: the widget's on-page corner and the chatbot's
            // text direction are independent settings (haman-widget.css's
            // :host/data-position rules).
            'position'    => 'bottom-right',
            'aiName'      => $is_fa ? 'دستیار هوشمند' : 'AI Assistant',
            'chatTitle'   => $is_fa ? 'پشتیبانی آنلاین' : 'Online Support',
            'placeholder' => $l10n_defaults['placeholder'],
            'sendButtonLabel'        => $l10n_defaults['sendButtonLabel'],
            'unavailableMessage'     => $l10n_defaults['unavailableMessage'],
            'genericErrorMessage'    => $l10n_defaults['genericErrorMessage'],
            'connectionErrorMessage' => $l10n_defaults['connectionErrorMessage'],
            'checkingAvailabilityMessage' => $l10n_defaults['checkingAvailabilityMessage'],
            'quickQuestions' => [],
            // Brand blue — mirrors config('haman.brand.primary_color') on
            // the server (laravel-backend/config/haman.php), enforced by
            // check-widget-brand-defaults.php so the two cannot drift apart
            // silently again the way they did before (this fallback was
            // still the pre-rebrand navy #1B3A6B long after the panels and
            // landing page moved on). Only visible for the instant before
            // /chat/session responds with whatever the merchant actually
            // set — never overrides a merchant's own chosen color.
            'primaryColor'     => '#0098F8',
            'avatarUrl'        => '',
            'poweredByEnabled' => true,
            'poweredByName'    => 'Haman AI',
            'poweredByUrl'     => 'https://hamanai.com',
            'i18n' => $i18n,
            'storeApiNonce' => $store_api_nonce,
            'storeApiUrl'   => $store_api_url,
            'cartUrl'       => $cart_url,
            'checkoutUrl'   => $checkout_url,
        ];
    }
}
