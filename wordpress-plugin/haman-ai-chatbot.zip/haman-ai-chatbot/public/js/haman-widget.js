/**
 * Haman AI Chatbot — front-end widget.
 *
 * Config arrives via wp_localize_script as window.HamanWidgetConfig (see
 * Haman_Public::build_config() in class-haman-public.php). Everything the
 * widget renders is built inside a Shadow DOM root attached to a single host
 * div appended to <body>, so the host theme's CSS can never reach in and
 * break the widget, and the widget's own CSS can never leak out and affect
 * the host page.
 */
(function () {
    'use strict';

    var CFG = window.HamanWidgetConfig;
    if (!CFG || !CFG.chatbotId || !CFG.apiUrl) return;

    var CONV_STORAGE_KEY = 'haman_conv_v1';
    var OPEN_STORAGE_KEY = 'haman_open_v1';
    var CONV_TTL_MS = 24 * 60 * 60 * 1000;

    // ── Persisted conversation (24h TTL) ──────────────────────────────
    function loadPersistedConv() {
        try {
            var raw = localStorage.getItem(CONV_STORAGE_KEY);
            if (!raw) return null;
            var obj = JSON.parse(raw);
            if (!obj || !obj.sessionId || !obj.savedAt) return null;
            if (Date.now() - obj.savedAt > CONV_TTL_MS) return null;
            return obj;
        } catch (e) { return null; }
    }
    function persistConv(sessionId, convId) {
        try {
            localStorage.setItem(CONV_STORAGE_KEY, JSON.stringify({
                sessionId: sessionId, convId: convId, savedAt: Date.now()
            }));
        } catch (e) { /* private-browsing / storage disabled — persistence just won't work */ }
        // Revenue attribution (doc-04) — localStorage isn't readable from a
        // normal PHP page load (WooCommerce's checkout/thank-you page is a
        // full navigation on the merchant's own site, not something this
        // widget's JS runs inside), so a real cookie is what lets
        // Haman_Sync_Manager::on_order_placed() attach this conversation
        // to an order later, if the same browser goes on to buy something.
        // Same 24h TTL as the localStorage copy above; document.cookie here
        // is the real top-level page's cookie jar (Shadow DOM only isolates
        // the DOM tree/styles, not this global), so it's actually readable
        // server-side on any later page load on this domain.
        try {
            document.cookie = 'haman_conv_id=' + encodeURIComponent(convId) +
                '; path=/; max-age=' + Math.floor(CONV_TTL_MS / 1000) + '; SameSite=Lax';
        } catch (e) { /* cookies disabled — order attribution just won't have a conversation_id */ }
    }
    function loadPersistedOpen() {
        try { return localStorage.getItem(OPEN_STORAGE_KEY) === '1'; } catch (e) { return false; }
    }
    function persistOpen(isOpenNow) {
        try { localStorage.setItem(OPEN_STORAGE_KEY, isOpenNow ? '1' : '0'); } catch (e) { /* ignore */ }
    }
    function genSessionId() { return 's_' + Math.random().toString(36).substr(2, 16); }

    // ── The chatbot's own config, remembered for the next first paint ──
    // Before /chat/session answers, the widget can only guess its language
    // from the WordPress locale (CFG, built in PHP) — a Persian chatbot on
    // an English site painted LTR/English first and flipped a moment later,
    // and so did its title, colour and avatar. The last config the server
    // sent is kept here and applied at boot instead; the server stays the
    // source of truth — its answer overwrites this on every session.
    var WCFG_STORAGE_KEY = 'haman_wcfg_v1';
    var WCFG_TTL_MS = 30 * 24 * 60 * 60 * 1000;
    function loadCachedConfig() {
        try {
            var obj = JSON.parse(localStorage.getItem(WCFG_STORAGE_KEY) || 'null');
            if (!obj || obj.chatbotId !== CFG.chatbotId || !obj.savedAt) return null;
            if (Date.now() - obj.savedAt > WCFG_TTL_MS) return null;
            return obj;
        } catch (e) { return null; }
    }
    function cacheConfig(language, wc) {
        try {
            localStorage.setItem(WCFG_STORAGE_KEY, JSON.stringify({
                chatbotId: CFG.chatbotId, language: language || null, wc: wc || null, savedAt: Date.now()
            }));
        } catch (e) { /* storage disabled — first paint just falls back to the WordPress locale */ }
    }
    var cachedConfig = loadCachedConfig();
    // The direction the very first paint uses (applied to #hm-w below).
    if (cachedConfig && cachedConfig.language) CFG.dir = cachedConfig.language === 'fa' ? 'rtl' : 'ltr';

    var persisted = loadPersistedConv();
    var H = {
        chatbotId: CFG.chatbotId,
        apiUrl: CFG.apiUrl,
        sessionId: (persisted && persisted.sessionId) || genSessionId(),
    };
    var persistedConvId = persisted ? persisted.convId : null;

    // ── Shadow DOM host ────────────────────────────────────────────────
    var hostEl = document.createElement('div');
    hostEl.id = 'haman-widget-host';
    // Which corner the widget sits in — deliberately a separate attribute
    // from `dir` (set on #hm-w below). The widget's on-page position and
    // the chatbot's text direction are independent settings; haman-widget.css
    // keys all position/alignment rules off data-position, never off dir,
    // so a Persian chatbot doesn't silently jump to the opposite corner.
    hostEl.setAttribute('data-position', CFG.position || 'bottom-right');
    document.body.appendChild(hostEl);
    var root = hostEl.attachShadow({ mode: 'open' });

    var styleLink = document.createElement('link');
    styleLink.rel = 'stylesheet';
    styleLink.href = CFG.cssUrl;
    root.appendChild(styleLink);

    // ── Color ──────────────────────────────────────────────────────────
    // #0098F8 mirrors config('haman.brand.primary_color') on the server —
    // see check-widget-brand-defaults.php, which fails the build if this
    // literal and that config value ever disagree. Not read live from the
    // server at this point: this is only the color for the instant before
    // /chat/session responds with whatever the merchant actually chose
    // (CFG.primaryColor below already carries THAT value when set).
    var BRAND_PRIMARY = '#0098F8';
    var BRAND_GRADIENT = 'linear-gradient(135deg, #0098F8, #4870F8, #7050F8)';

    function hexToRgb(hex) {
        var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '');
        return m ? { r: parseInt(m[1], 16), g: parseInt(m[2], 16), b: parseInt(m[3], 16) } : null;
    }
    function toHex(n) {
        var h = Math.max(0, Math.min(255, Math.round(n))).toString(16);
        return h.length === 1 ? '0' + h : h;
    }
    /** Same hue, lighter — used only to build a two-stop gradient FROM a
     *  merchant's own chosen color, never to invent a second brand hue on
     *  top of a choice that isn't ours to override. */
    function lighten(rgb, amount) {
        return '#' + toHex(rgb.r + (255 - rgb.r) * amount) + toHex(rgb.g + (255 - rgb.g) * amount) + toHex(rgb.b + (255 - rgb.b) * amount);
    }
    function gradientFor(primary) {
        if (!primary || primary.toUpperCase() === BRAND_PRIMARY) return BRAND_GRADIENT;
        var rgb = hexToRgb(primary);
        if (!rgb) return BRAND_GRADIENT;
        return 'linear-gradient(135deg, ' + primary + ', ' + lighten(rgb, .32) + ')';
    }
    function setThemeVars(primaryColor) {
        var color = primaryColor || BRAND_PRIMARY;
        hostEl.style.setProperty('--hm-primary', color);
        hostEl.style.setProperty('--hm-gradient', gradientFor(color));
    }
    setThemeVars(CFG.primaryColor);

    // ── Brand mark (replaces the plain emoji glyph everywhere it used to
    // appear) ──────────────────────────────────────────────────────────
    // Two renderings of the same mark from resources/brand/ — see
    // partials/brand-logo.blade.php, which this mirrors: a flat white
    // silhouette for the header/floating-button badges (sitting on
    // var(--hm-primary) or the gradient, i.e. an unpredictable color a
    // merchant may have chosen — a gradient-filled mark risks vanishing
    // against its own background there), and the real gradient-filled mark
    // for the footer, which always sits on a plain white strip.
    function markMono() {
        // An admin-uploaded mark (Settings > Brand, server-side) always wins
        // once /chat/session has responded — see applyWidgetConfig() below.
        // Until then, and if nothing's been uploaded, this is the same
        // built-in silhouette it always was.
        if (CFG.poweredByMarkLightUrl) {
            return '<img src="' + esc(CFG.poweredByMarkLightUrl) + '" alt="' + esc(CFG.poweredByName || 'Haman AI') + '">';
        }
        return '<svg viewBox="0 0 112 131" role="img" aria-label="Haman AI">' +
            '<path d="M 44 9 L 11 34 L 11 116 C 11 120, 13 122, 17 121 C 26 112, 39 98, 46 84 L 46 40 C 46 30, 45 18, 44 9 Z" fill="#FFFFFF"/>' +
            '<path d="M 68 9 L 101 34 L 101 116 C 101 120, 99 122, 95 121 C 86 112, 73 98, 66 84 L 66 40 C 66 30, 67 18, 68 9 Z" fill="#FFFFFF" fill-opacity="0.75"/>' +
            '<path d="M 27 47 h 58 a 15 15 0 0 1 15 15 v 5 a 15 15 0 0 1 -15 15 h -33 q -9 7, -13 7 q -3 0, -2 -3 q 1 -2, 2 -4 h -12 a 15 15 0 0 1 -15 -15 v -5 a 15 15 0 0 1 15 -15 Z" fill="none" stroke="#FFFFFF" stroke-width="6"/>' +
        '</svg>';
    }
    function markColor(id) {
        if (CFG.poweredByMarkUrl) {
            return '<img src="' + esc(CFG.poweredByMarkUrl) + '" alt="">';
        }
        return '<svg viewBox="0 0 112 131" role="img" aria-label="Haman AI">' +
            '<defs>' +
                '<linearGradient id="' + id + '-m" x1="0" y1="0" x2="112" y2="131" gradientUnits="userSpaceOnUse">' +
                    '<stop offset="0" stop-color="#0098F8"/><stop offset="0.5" stop-color="#4870F8"/><stop offset="1" stop-color="#7050F8"/>' +
                '</linearGradient>' +
                '<linearGradient id="' + id + '-b" x1="0" y1="0" x2="1" y2="1">' +
                    '<stop offset="0" stop-color="#0098F8"/><stop offset="1" stop-color="#4870F8"/>' +
                '</linearGradient>' +
            '</defs>' +
            '<path d="M 44 9 L 11 34 L 11 116 C 11 120, 13 122, 17 121 C 26 112, 39 98, 46 84 L 46 40 C 46 30, 45 18, 44 9 Z" fill="url(#' + id + '-m)"/>' +
            '<path d="M 68 9 L 101 34 L 101 116 C 101 120, 99 122, 95 121 C 86 112, 73 98, 66 84 L 66 40 C 66 30, 67 18, 68 9 Z" fill="url(#' + id + '-m)"/>' +
            '<path d="M 27 47 h 58 a 15 15 0 0 1 15 15 v 5 a 15 15 0 0 1 -15 15 h -33 q -9 7, -13 7 q -3 0, -2 -3 q 1 -2, 2 -4 h -12 a 15 15 0 0 1 -15 -15 v -5 a 15 15 0 0 1 15 -15 Z" fill="none" stroke="#FFFFFF" stroke-width="5.5"/>' +
            '<path d="M 27 47 h 58 a 15 15 0 0 1 15 15 v 5 a 15 15 0 0 1 -15 15 h -33 q -9 7, -13 7 q -3 0, -2 -3 q 1 -2, 2 -4 h -12 a 15 15 0 0 1 -15 -15 v -5 a 15 15 0 0 1 15 -15 Z" fill="url(#' + id + '-b)"/>' +
            '<circle cx="46" cy="62" r="3.2" fill="#fff"/><circle cx="56" cy="62" r="3.2" fill="#fff"/><circle cx="66" cy="62" r="3.2" fill="#fff"/>' +
        '</svg>';
    }
    /** A merchant's own uploaded avatar always wins — see WidgetDefaults.php
     *  on the server, "admin-settable, same override path as primary_color".
     *  This is only ever the DEFAULT before/absent that choice. */
    function avatarSlotHtml(url) {
        return url ? '<img src="' + esc(url) + '" alt="">' : markMono();
    }

    function esc(t) {
        var d = document.createElement('div');
        d.textContent = t == null ? '' : t;
        return d.innerHTML;
    }
    // Bold/italic/link only — factored out of mdToHtml() so a markdown
    // table's own cells get the same inline formatting as regular prose,
    // without re-running \n -> <br> (a table's rows are joined by real
    // <tr> tags, not <br>, and its cells never contain a literal newline).
    function inlineMdToHtml(line) {
        return line
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:var(--hm-primary);text-decoration:underline">$1</a>');
    }

    function isMdTableRow(line) {
        return line.indexOf('|') !== -1 && line.trim() !== '';
    }

    // A GFM-style separator row: "---", "| --- | --- |", ":---:", etc.
    // Requires at least one cell so a stray line of just dashes/pipes with
    // nothing else can't be mistaken for one.
    function isMdTableSeparator(line) {
        return /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$/.test(line);
    }

    function splitMdTableRow(line) {
        var trimmed = line.trim().replace(/^\|/, '').replace(/\|$/, '');
        return trimmed.split('|').map(function (c) { return c.trim(); });
    }

    function mdTableToHtml(headerCells, bodyRows) {
        var thead = '<tr>' + headerCells.map(function (c) {
            return '<th>' + inlineMdToHtml(c) + '</th>';
        }).join('') + '</tr>';
        var tbody = bodyRows.map(function (row) {
            return '<tr>' + row.map(function (c) {
                return '<td>' + inlineMdToHtml(c) + '</td>';
            }).join('') + '</tr>';
        }).join('');
        return '<div class="hm-md-table-wrap"><table class="hm-md-table"><thead>' + thead
            + '</thead><tbody>' + tbody + '</tbody></table></div>';
    }

    // A comparison question doesn't always go through the compare_products
    // tool (it's opt-in, and even enabled, the model can still answer in
    // plain prose) — when it doesn't, a markdown pipe-table in the model's
    // own text used to render as literal "| a | b |" lines. Detected and
    // converted to a real, horizontally-scrollable <table> here; everything
    // else keeps the exact prior behavior (bold/italic/link, then \n -> <br>).
    function mdToHtml(t) {
        var lines = esc(t).split('\n');
        var out = [];
        var i = 0;
        while (i < lines.length) {
            if (isMdTableRow(lines[i]) && i + 1 < lines.length && isMdTableSeparator(lines[i + 1])) {
                var header = splitMdTableRow(lines[i]);
                var rows = [];
                var j = i + 2;
                while (j < lines.length && isMdTableRow(lines[j]) && !isMdTableSeparator(lines[j])) {
                    rows.push(splitMdTableRow(lines[j]));
                    j++;
                }
                out.push(mdTableToHtml(header, rows));
                i = j;
            } else {
                out.push(inlineMdToHtml(lines[i]));
                i++;
            }
        }
        return out.join('<br>');
    }

    // ── Markup ─────────────────────────────────────────────────────────
    var w = document.createElement('div');
    w.id = 'hm-w';
    w.setAttribute('dir', CFG.dir || 'ltr');

    var qqHtml = '';
    if (CFG.quickQuestions && CFG.quickQuestions.length) {
        qqHtml = '<div id="hm-qq">' + CFG.quickQuestions.map(function (q, i) {
            return '<button type="button" data-i="' + i + '">' + esc(q.question) + '</button>';
        }).join('') + '</div>';
    }

    // Avatar is optional per chatbot (Appearance settings) — falls back to
    // the brand mark on both the header and the floating button when unset,
    // instead of the plain emoji glyph this used to be.
    var avatarHtml = avatarSlotHtml(CFG.avatarUrl);

    w.innerHTML =
        '<div id="hm-box" role="dialog" aria-modal="false" aria-label="' + esc(CFG.i18n.dialogLabel) + '" aria-hidden="true">' +
            '<div id="hm-hdr">' +
                '<div id="hm-avatar-hdr">' + avatarHtml + '</div>' +
                '<div id="hm-hdr-text"><h3>' + esc(CFG.chatTitle) + '</h3><span>' + esc(CFG.aiName) + '</span></div>' +
                '<button id="hm-close" type="button" aria-label="' + esc(CFG.i18n.closeLabel) + '">✕</button>' +
            '</div>' +
            '<div id="hm-msgs" aria-live="polite"></div>' +
            qqHtml +
            '<div id="hm-in-row">' +
                '<textarea id="hm-in" rows="1" placeholder="' + esc(CFG.placeholder) + '"></textarea>' +
                '<button id="hm-send" type="button">' + esc(CFG.sendButtonLabel) + '</button>' +
            '</div>' +
            '<div id="hm-powered"></div>' +
        '</div>' +
        '<button id="hm-btn" type="button" aria-label="' + esc(CFG.i18n.openLabel) + '" aria-expanded="false">' +
            '<span id="hm-avatar-btn">' + avatarHtml + '</span>' +
            '<span id="hm-unread-dot" aria-hidden="true"></span>' +
        '</button>';

    root.appendChild(w);

    var box = root.getElementById('hm-box');
    var msgs = root.getElementById('hm-msgs');
    var inp = root.getElementById('hm-in');
    var sendBtn = root.getElementById('hm-send');
    var qqBox = root.getElementById('hm-qq');
    var closeBtn = root.getElementById('hm-close');
    var openBtn = root.getElementById('hm-btn');
    var unreadDot = root.getElementById('hm-unread-dot');
    var poweredEl = root.getElementById('hm-powered');

    function renderPoweredBy() {
        if (CFG.poweredByEnabled === false) { poweredEl.style.display = 'none'; return; }
        poweredEl.innerHTML = '<a href="' + esc(CFG.poweredByUrl || 'https://hamanai.com') +
            '" target="_blank" rel="noopener">' + markColor('hm-mark-ftr') + esc(CFG.poweredByName || 'Haman AI') + '</a>';
    }
    renderPoweredBy();

    var convId = persistedConvId;
    var isOpen = false;
    var unavailable = false;
    var historyLoaded = false;
    // Whether init() has been called yet THIS page load — deliberately
    // separate from convId. convId starts non-null the moment a returning
    // visitor's persisted conversation is loaded from storage (see
    // `var convId = persistedConvId` above), well before the widget is
    // ever opened — a `!convId` guard on calling init() therefore skipped
    // init() (and with it, both history loading AND the welcome message)
    // for every returning visitor, since convId already looked "set" even
    // though nothing had actually been fetched or rendered yet this
    // pageview. This flag tracks the real thing that must only happen once.
    var sessionInitStarted = false;
    var typingEl = null;
    var typingLabelTimer = null;
    // A normal reply's first token arrives well under this; a tool call
    // hitting a slow store's live-query endpoint (see
    // LIVE_QUERY_TIMEOUT_SECONDS, product_tools.py) can take several
    // seconds, which is exactly when the plain dots stop being enough.
    var CHECKING_LABEL_DELAY_MS = 2500;

    // ── Scroll-to-bottom affordance ───────────────────────────────────
    var scrollBtn = document.createElement('button');
    scrollBtn.type = 'button';
    scrollBtn.id = 'hm-scroll-bottom';
    scrollBtn.setAttribute('aria-label', CFG.i18n.scrollToBottomLabel);
    scrollBtn.innerHTML = '↓';
    box.insertBefore(scrollBtn, msgs.nextSibling);
    scrollBtn.addEventListener('click', function () { scrollToBottom(true); });

    function isNearBottom() {
        return msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight < 60;
    }
    function scrollToBottom(smooth) {
        msgs.scrollTo({ top: msgs.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    }
    msgs.addEventListener('scroll', function () {
        scrollBtn.classList.toggle('hm-visible', !isNearBottom());
    });

    // ── Messages ───────────────────────────────────────────────────────
    // Bot bubbles wrap their rendered text in a nested .hm-msg-text span,
    // separate from the copy button — updateBotBubble() (used while a
    // streamed reply is still arriving) only ever touches that span's
    // innerHTML, so it never wipes out the copy button the way replacing
    // the whole bubble's innerHTML would.
    function addMsg(text, role, opts) {
        opts = opts || {};
        var d = document.createElement('div');
        d.className = 'hm-msg ' + (role === 'user' ? 'user' : 'bot');
        if (role === 'bot') {
            var textSpan = document.createElement('span');
            textSpan.className = 'hm-msg-text';
            textSpan.innerHTML = mdToHtml(text);
            d.appendChild(textSpan);
            d.dataset.rawText = text;
            var copyBtn = document.createElement('button');
            copyBtn.type = 'button';
            copyBtn.className = 'hm-msg-copy';
            copyBtn.setAttribute('aria-label', CFG.i18n.copyLabel);
            copyBtn.innerHTML = '⧉';
            copyBtn.addEventListener('click', function () { copyMessage(d.dataset.rawText, copyBtn); });
            d.appendChild(copyBtn);
        } else {
            d.textContent = text;
        }
        var wasNearBottom = isNearBottom();
        msgs.appendChild(d);
        if (wasNearBottom || role === 'user') scrollToBottom(false);
        if (role === 'bot' && !isOpen) {
            unreadDot.classList.add('hm-visible');
        }
        return d;
    }

    function updateBotBubble(bubbleEl, fullText) {
        var span = bubbleEl.querySelector('.hm-msg-text');
        if (span) span.innerHTML = mdToHtml(fullText);
        bubbleEl.dataset.rawText = fullText;
        if (isNearBottom()) scrollToBottom(false);
    }

    function copyMessage(text, btnEl) {
        var done = function () {
            var original = btnEl.innerHTML;
            btnEl.setAttribute('aria-label', CFG.i18n.copiedLabel);
            btnEl.innerHTML = '✓';
            setTimeout(function () {
                btnEl.innerHTML = original;
                btnEl.setAttribute('aria-label', CFG.i18n.copyLabel);
            }, 1500);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () {});
        } else {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            root.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); done(); } catch (e) { /* ignore */ }
            root.removeChild(ta);
        }
    }

    function showTyping() {
        typingEl = document.createElement('div');
        typingEl.className = 'hm-typing';
        typingEl.innerHTML = '<span></span><span></span><span></span>';
        msgs.appendChild(typingEl);
        scrollToBottom(false);

        typingLabelTimer = setTimeout(function () {
            if (!typingEl || !CFG.checkingAvailabilityMessage) return;
            var label = document.createElement('span');
            label.className = 'hm-typing-label';
            label.textContent = CFG.checkingAvailabilityMessage;
            typingEl.appendChild(label);
            scrollToBottom(false);
        }, CHECKING_LABEL_DELAY_MS);
    }
    function hideTyping() {
        if (typingLabelTimer) { clearTimeout(typingLabelTimer); typingLabelTimer = null; }
        if (typingEl && typingEl.parentNode) typingEl.parentNode.removeChild(typingEl);
        typingEl = null;
    }

    // ── Product cards / comparison table ───────────────────────────────
    // Structured content from recommend_products/compare_products (see
    // tool_calling_service._build_widget_block() on the Python side) —
    // rendered as real DOM (cards, a table), never dumped as text the
    // model would otherwise have to hand-format. Both card strip and
    // table wrapper scroll horizontally rather than trying to squeeze
    // multiple columns into the widget's ~360px (or full-width-mobile)
    // box, which is what actually makes them render correctly at any
    // width instead of just at one.
    function formatPrice(price, currency) {
        if (price === null || typeof price === 'undefined') return '';
        var n = Number(price);
        if (isNaN(n)) return '';
        return n.toLocaleString() + (currency ? ' ' + currency : '');
    }

    function renderWidgetBlocks(blocks) {
        if (!blocks || !blocks.length) return;
        var wasNearBottom = isNearBottom();
        blocks.forEach(function (block) {
            // Fault-isolated: one block's own rendering bug must never take
            // every block after it in this same turn down too. A plain
            // forEach with no try/catch meant a single throw partway
            // through would silently abort the whole loop, and multiple
            // blocks in one turn (e.g. a product_compare alongside an
            // add_to_cart, both real, same response) is an entirely normal
            // shape — investigated 2026-10-22 as a candidate (unconfirmed)
            // explanation for a comparison table that didn't render.
            try {
                if (block.type === 'product_cards') renderProductCards(block.products);
                else if (block.type === 'product_compare') renderCompareTable(block.products, block.attribute_rows);
                else if (block.type === 'cart_links') renderCartLinks(block.items);
                else if (block.type === 'add_to_cart') renderAddToCartIntent(block.items);
                else if (block.type === 'payment_link_preview') renderPaymentLinkPreview(block);
                else if (block.type === 'order_status_otp') renderOrderStatusOtp(block);
            } catch (e) {
                if (window.console && console.error) {
                    console.error('Haman widget: failed to render a "' + block.type + '" block', e);
                }
            }
        });
        if (wasNearBottom) scrollToBottom(false);
    }

    // build_cart_url's items are plain WooCommerce ?add-to-cart=ID GET
    // links — the click itself is what adds the item, this button is just
    // real UI for that link, not something that adds anything on its own.
    function renderCartLinks(items) {
        if (!items || !items.length) return;
        var wrap = document.createElement('div');
        wrap.className = 'hm-cart-links';
        items.forEach(function (it) {
            var btn = document.createElement('a');
            btn.className = 'hm-cart-link-btn';
            btn.href = it.url;
            btn.target = '_blank';
            btn.rel = 'noopener';
            var qtyText = (it.quantity && it.quantity > 1) ? ' × ' + it.quantity : '';
            btn.textContent = CFG.i18n.addToCartLabel + qtyText;
            wrap.appendChild(btn);
        });
        msgs.appendChild(wrap);
    }

    // ── add_to_cart (Store API, same-origin) ───────────────────────────
    // The customer's explicit consent is the model calling this tool at
    // all — add_to_cart is only ever called on an explicit "add this"/
    // "buy this" instruction (see intent_classifier.py's "purchase"
    // intent and product_tools.add_to_cart's own docstring), never from a
    // plain availability/price question. Given that consent, this fires
    // the real Store API call the instant the block renders — same-origin,
    // with the browser's own cookies + a nonce the plugin already
    // embedded in CFG at page-render time (see class-haman-public.php) —
    // with no second click needed; asking the customer to click again
    // when they already told us to add it would just be friction.
    //
    // The model's own text reply can never truthfully claim this
    // succeeded (see claim_guard.py's cart_add rule): the Store API call
    // only runs in THIS browser, after that reply was already generated
    // and sent, so the model cannot know the outcome yet. Everything the
    // customer sees confirmed here — item count, real total, cart/
    // checkout links — comes only from actually reading the cart the
    // Store API handed back, never from anything the model wrote.
    function storeApiAvailable() {
        return !!(CFG.storeApiUrl && CFG.storeApiNonce);
    }

    function classicCartUrl(productId, quantity) {
        return window.location.origin + '/?add-to-cart=' + encodeURIComponent(productId) +
            '&quantity=' + encodeURIComponent(quantity || 1);
    }

    function renderAddToCartIntent(items) {
        if (!items || !items.length) return;
        var wrap = document.createElement('div');
        wrap.className = 'hm-atc-items';
        items.forEach(function (it) {
            var row = document.createElement('div');
            row.className = 'hm-atc-item';

            var nameEl = document.createElement('span');
            nameEl.className = 'hm-atc-name';
            var qtyText = (it.quantity && it.quantity > 1) ? ' × ' + it.quantity : '';
            nameEl.textContent = (it.name || '') + qtyText;
            row.appendChild(nameEl);

            var statusEl = document.createElement('span');
            statusEl.className = 'hm-atc-status';
            row.appendChild(statusEl);
            wrap.appendChild(row);

            if (!storeApiAvailable()) {
                // Store API not available at all (old WooCommerce / Store
                // API disabled) — nothing to auto-run, so hand over the
                // classic link immediately. Built client-side since the
                // widget already knows its own origin (no server round
                // trip needed for this).
                appendClassicLinkFallback(row, it);
                return;
            }

            statusEl.textContent = CFG.i18n.addingToCartLabel;
            autoAddToCart(it, statusEl, row);
        });
        msgs.appendChild(wrap);
    }

    // The one function in this whole file that actually mutates the
    // customer's real cart — fires the instant renderAddToCartIntent()
    // builds the row above, no click involved. isRetry guards the one
    // nonce-refresh-and-retry below from looping.
    function addToCartViaStoreApi(item, isRetry) {
        var targetId = item.variation_id || item.product_id;
        return fetch(CFG.storeApiUrl + 'cart/add-item', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Nonce': CFG.storeApiNonce },
            body: JSON.stringify({ id: targetId, quantity: item.quantity || 1 }),
        }).then(function (r) {
            return r.json().catch(function () { return {}; }).then(function (data) {
                return { ok: r.ok, status: r.status, data: data, headers: r.headers };
            });
        });
    }

    function refreshStoreApiNonce() {
        return fetch(CFG.storeApiUrl + 'cart', { method: 'GET' })
            .then(function (r) {
                // Store API convention: a fresh nonce comes back on every
                // response as a header — checked under both names actually
                // seen in the wild, since this isn't pinned to one exact
                // WooCommerce version.
                var fresh = r.headers.get('Nonce') || r.headers.get('X-WC-Store-API-Nonce');
                if (fresh) CFG.storeApiNonce = fresh;
                return !!fresh;
            })
            .catch(function () { return false; });
    }

    // A 200 response is not proof by itself — read the cart it actually
    // returned and confirm the item is really in there before telling the
    // customer it worked. "We measured, we didn't just trust the status
    // code" is the whole point of this feature, not an afterthought.
    function cartReallyHasItem(cartData, item) {
        var targetId = Number(item.variation_id || item.product_id);
        var cartItems = (cartData && cartData.items) || [];
        return cartItems.some(function (ci) { return Number(ci.id) === targetId; });
    }

    function autoAddToCart(item, statusEl, row) {
        function attempt(isRetry) {
            addToCartViaStoreApi(item, isRetry).then(function (res) {
                if (res.ok && cartReallyHasItem(res.data, item)) {
                    onAddToCartSuccess(item, statusEl, res.data);
                    return;
                }
                var code = String((res.data && (res.data.code || res.data.message)) || '').toLowerCase();
                var isNonceIssue = (res.status === 401 || res.status === 403) && !isRetry;
                if (isNonceIssue) {
                    refreshStoreApiNonce().then(function (refreshed) {
                        if (refreshed) { attempt(true); return; }
                        onAddToCartFailure(statusEl, row, item, code || 'not_confirmed');
                    });
                    return;
                }
                onAddToCartFailure(statusEl, row, item, code || 'not_confirmed');
            }).catch(function () {
                // Network-level failure (Store API route missing entirely —
                // old WooCommerce or the API disabled — or genuinely
                // offline): no error code to classify, straight to the
                // classic link, same fallback build_cart_url already uses.
                statusEl.textContent = '';
                appendClassicLinkFallback(row, item);
            });
        }
        attempt(false);
    }

    function formatCartTotal(totals) {
        if (!totals || totals.total_price == null) return '';
        var minorUnit = Number(totals.currency_minor_unit);
        if (!isFinite(minorUnit) || minorUnit < 0) minorUnit = 0;
        var amount = Number(totals.total_price) / Math.pow(10, minorUnit);
        if (!isFinite(amount)) return '';
        // Store API's own currency fields, not a hardcoded symbol — this
        // respects whatever currency/format the store owner configured
        // instead of assuming Toman/Rial.
        var prefix = totals.currency_prefix || '';
        var suffix = totals.currency_suffix || (totals.currency_code ? ' ' + totals.currency_code : '');
        return prefix + amount.toLocaleString() + suffix;
    }

    function onAddToCartSuccess(item, statusEl, cartData) {
        var count = (cartData && typeof cartData.items_count === 'number') ? cartData.items_count : null;
        var countText = count !== null ? CFG.i18n.itemsInCartLabel.replace(':count', count) : '';
        var totalText = formatCartTotal(cartData && cartData.totals);
        var totalHtml = totalText ? '، ' + esc(CFG.i18n.orderTotalLabel) + ': <strong>' + esc(totalText) + '</strong>' : '';
        var viewCartHtml = CFG.cartUrl ? ' <a href="' + esc(CFG.cartUrl) + '" target="_blank" rel="noopener">' + esc(CFG.i18n.viewCartLabel) + '</a>' : '';
        var checkoutHtml = CFG.checkoutUrl ? ' <a href="' + esc(CFG.checkoutUrl) + '" target="_blank" rel="noopener">' + esc(CFG.i18n.checkoutLabel) + '</a>' : '';
        statusEl.className = 'hm-atc-status hm-atc-success';
        statusEl.innerHTML = '✓ ' + esc(countText) + totalHtml + viewCartHtml + checkoutHtml;

        // Real, confirmed outcome — see ChatController::cartEvent() and
        // claim_guard.py's cart_add rule on why this is only ever logged
        // HERE, after cartReallyHasItem() confirmed it, never at tool-call
        // time. Fire-and-forget: this must never block or fail the UI the
        // customer already sees succeed.
        fetch(H.apiUrl + '/chat/cart-event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chatbot_id: H.chatbotId, conversation_id: convId,
                product_id: item.product_id, variation_id: item.variation_id || null,
            }),
        }).catch(function () { /* best-effort — the real cart add already succeeded regardless */ });
    }

    function onAddToCartFailure(statusEl, row, item, code) {
        var msg;
        if (code.indexOf('stock') !== -1) {
            msg = CFG.i18n.outOfStockAddErrorLabel;
        } else if (code.indexOf('variation') !== -1 || code.indexOf('attribute') !== -1) {
            msg = CFG.i18n.chooseVariantLabel;
        } else {
            msg = CFG.i18n.genericAddErrorLabel;
        }
        statusEl.className = 'hm-atc-status hm-atc-error';
        statusEl.textContent = msg;
        // Whatever actually went wrong (no cookie, a nonce that couldn't
        // be refreshed, a stale stock check, a genuine network failure),
        // the customer still gets a real way forward: WooCommerce's own
        // nonce-free link, which needs no JavaScript at all and goes
        // through WooCommerce's normal validation itself regardless — two
        // paths, never just the one that already failed.
        appendClassicLinkFallback(row, item);
    }

    function appendClassicLinkFallback(row, item) {
        var link = document.createElement('a');
        link.className = 'hm-cart-link-btn hm-atc-fallback-link';
        link.href = classicCartUrl(item.product_id, item.quantity);
        link.target = '_blank';
        link.rel = 'noopener';
        link.textContent = CFG.i18n.addToCartLabel;
        row.appendChild(link);
    }

    // ── create_payment_link (doc-04) ───────────────────────────────────
    // The tool result is a PREVIEW only — real items/total, but no order
    // exists yet. This renders that preview plus a real "Confirm & Pay"
    // button; the actual order (and the real, one-time-use payment URL)
    // is only ever created inside this button's own click handler, never
    // automatically. The order_pay_url below is used only to set an
    // <a href> and is never logged, stored, or referenced again after
    // that — matching the task's own "never persist the key/URL" rule on
    // this side of the wire too.
    function renderPaymentLinkPreview(block) {
        if (!block.items || !block.items.length || block.total == null) return;
        var wrap = document.createElement('div');
        wrap.className = 'hm-payment-preview';

        var itemsHtml = '<ul class="hm-payment-items">' + block.items.map(function (it) {
            var qtyText = (it.quantity && it.quantity > 1) ? ' × ' + it.quantity : '';
            return '<li><span>' + esc(it.name || '') + qtyText + '</span><span>' + esc(formatPrice(it.line_total, block.currency)) + '</span></li>';
        }).join('') + '</ul>';
        var totalHtml = '<div class="hm-payment-total">' + esc(CFG.i18n.orderTotalLabel) + ': <strong>' + esc(formatPrice(block.total, block.currency)) + '</strong></div>';
        wrap.innerHTML = itemsHtml + totalHtml;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'hm-payment-confirm-btn';
        btn.textContent = CFG.i18n.confirmAndPayLabel;
        var statusEl = document.createElement('div');
        statusEl.className = 'hm-payment-status';
        statusEl.hidden = true;
        btn.addEventListener('click', function () {
            handleConfirmPaymentClick(block, btn, statusEl);
        });
        wrap.appendChild(btn);
        wrap.appendChild(statusEl);

        msgs.appendChild(wrap);
    }

    // get_order_status, phase 1. Nothing has been sent or looked up when
    // this renders — the tool returns intent only. Sending an SMS costs
    // the merchant money, so it takes a real click, exactly like the
    // payment-link button below.
    function renderOrderStatusOtp(block) {
        if (!block.contact) return;
        var wrap = document.createElement('div');
        wrap.className = 'hm-order-status';

        var prompt = document.createElement('div');
        prompt.className = 'hm-order-status-prompt';
        prompt.textContent = CFG.i18n.sendCodeToLabel + ' ' + block.contact;
        wrap.appendChild(prompt);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'hm-order-status-btn';
        btn.textContent = CFG.i18n.sendCodeLabel;
        var statusEl = document.createElement('div');
        statusEl.className = 'hm-order-status-msg';
        statusEl.hidden = true;
        btn.addEventListener('click', function () {
            handleSendOrderStatusCode(block, btn, statusEl, wrap);
        });
        wrap.appendChild(btn);
        wrap.appendChild(statusEl);

        msgs.appendChild(wrap);
    }

    function setOrderStatusError(statusEl, text) {
        statusEl.hidden = false;
        statusEl.className = 'hm-order-status-msg hm-order-status-error';
        statusEl.textContent = text;
    }

    // Asks the server to send a code. The server refuses — without
    // sending anything — unless this number actually appears on an order
    // at this store, which is the whole reason this cannot be abused as a
    // free SMS sender. This call carries no trust of its own.
    function handleSendOrderStatusCode(block, btnEl, statusEl, wrap) {
        btnEl.disabled = true;
        btnEl.textContent = CFG.i18n.sendingCodeLabel;

        fetch(H.apiUrl + '/chat/order-status/request-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chatbot_id: H.chatbotId,
                conversation_id: convId,
                contact: block.contact,
            }),
        })
            .then(function (r) {
                return r.json().catch(function () { return {}; }).then(function (data) {
                    return { ok: r.ok, data: data };
                });
            })
            .then(function (res) {
                var payload = res.ok && res.data && res.data.data;
                if (payload && payload.sent) {
                    btnEl.hidden = true;
                    statusEl.hidden = true;
                    renderOrderStatusCodeInput(block, wrap);
                    return;
                }
                btnEl.disabled = false;
                btnEl.textContent = CFG.i18n.sendCodeLabel;
                // "No orders for that number" is a normal, expected answer,
                // not a failure — and importantly it means nothing was sent.
                if (payload && payload.sent === false) {
                    setOrderStatusError(statusEl, CFG.i18n.noOrdersFoundLabel);
                } else {
                    setOrderStatusError(statusEl, CFG.i18n.orderStatusErrorLabel);
                }
            })
            .catch(function () {
                btnEl.disabled = false;
                btnEl.textContent = CFG.i18n.sendCodeLabel;
                setOrderStatusError(statusEl, CFG.i18n.orderStatusErrorLabel);
            });
    }

    // The code gets its own field here, deliberately: a code typed into
    // the chat itself would be sent to the model and stored in message
    // history. It never leaves this form.
    function renderOrderStatusCodeInput(block, wrap) {
        var form = document.createElement('div');
        form.className = 'hm-order-status-verify';

        var label = document.createElement('div');
        label.className = 'hm-order-status-prompt';
        label.textContent = CFG.i18n.enterCodeLabel;
        form.appendChild(label);

        var input = document.createElement('input');
        input.type = 'text';
        input.inputMode = 'numeric';
        input.autocomplete = 'one-time-code';
        input.maxLength = 10;
        input.className = 'hm-order-status-input';
        form.appendChild(input);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'hm-order-status-btn';
        btn.textContent = CFG.i18n.verifyCodeLabel;
        form.appendChild(btn);

        var msg = document.createElement('div');
        msg.className = 'hm-order-status-msg';
        msg.hidden = true;
        form.appendChild(msg);

        btn.addEventListener('click', function () {
            handleVerifyOrderStatusCode(block, input, btn, msg, form);
        });
        input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') btn.click();
        });

        wrap.appendChild(form);
        input.focus();
    }

    function handleVerifyOrderStatusCode(block, inputEl, btnEl, msgEl, form) {
        var code = (inputEl.value || '').trim();
        if (!code) return;
        btnEl.disabled = true;
        inputEl.disabled = true;
        btnEl.textContent = CFG.i18n.verifyingCodeLabel;

        fetch(H.apiUrl + '/chat/order-status/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chatbot_id: H.chatbotId,
                conversation_id: convId,
                contact: block.contact,
                code: code,
            }),
        })
            .then(function (r) {
                return r.json().catch(function () { return {}; }).then(function (data) {
                    return { ok: r.ok, data: data };
                });
            })
            .then(function (res) {
                var orders = res.ok && res.data && res.data.data && res.data.data.orders;
                if (orders) {
                    form.hidden = true;
                    renderOrderList(orders, form.parentNode);
                    return;
                }
                btnEl.disabled = false;
                inputEl.disabled = false;
                inputEl.value = '';
                btnEl.textContent = CFG.i18n.verifyCodeLabel;
                setOrderStatusError(msgEl, CFG.i18n.codeIncorrectLabel);
            })
            .catch(function () {
                btnEl.disabled = false;
                inputEl.disabled = false;
                btnEl.textContent = CFG.i18n.verifyCodeLabel;
                setOrderStatusError(msgEl, CFG.i18n.orderStatusErrorLabel);
            });
    }

    // Status, tracking code and item names only — that is everything the
    // server is willing to send, and the plugin never puts an address or
    // payment reference on the wire in the first place.
    function renderOrderList(orders, wrap) {
        var list = document.createElement('div');
        list.className = 'hm-order-list';
        if (!orders.length) {
            list.textContent = CFG.i18n.noOrdersFoundLabel;
            wrap.appendChild(list);
            return;
        }
        orders.forEach(function (o) {
            var card = document.createElement('div');
            card.className = 'hm-order-card';
            var head = '<div class="hm-order-head"><span dir="ltr">#' + esc(o.number || '') + '</span>'
                + '<span class="hm-order-state">' + esc(orderStatusLabel(o.status)) + '</span></div>';
            var meta = '';
            if (o.date_created) {
                meta += '<div class="hm-order-meta"><span dir="ltr">' + esc(o.date_created) + '</span></div>';
            }
            if (o.tracking) {
                meta += '<div class="hm-order-meta">' + esc(CFG.i18n.trackingLabel) + ': <span dir="ltr">' + esc(o.tracking) + '</span></div>';
            }
            var items = (o.items && o.items.length)
                ? '<ul class="hm-order-items">' + o.items.map(function (it) {
                    var qty = (it.quantity && it.quantity > 1) ? ' × ' + it.quantity : '';
                    return '<li>' + esc(it.name || '') + qty + '</li>';
                }).join('') + '</ul>'
                : '';
            card.innerHTML = head + meta + items;
            list.appendChild(card);
        });
        wrap.appendChild(list);
    }

    function orderStatusLabel(status) {
        var map = CFG.i18n.orderStatuses || {};
        return map[status] || status || '';
    }

    // The one function in this file that creates a real WooCommerce
    // order — reached only from a real 'click' on the button
    // renderPaymentLinkPreview() built above, never automatically.
    // ChatController::createPaymentLink() re-checks everything (enabled,
    // amount cap, per-conversation/per-IP-per-day limits, a fresh live
    // total) server-side before creating anything; this call carries no
    // trust of its own beyond "the customer clicked confirm".
    function handleConfirmPaymentClick(block, btnEl, statusEl) {
        btnEl.disabled = true;
        var originalLabel = btnEl.textContent;
        btnEl.textContent = CFG.i18n.creatingOrderLabel;

        var items = block.items.map(function (it) {
            var out = { product_id: it.product_id, quantity: it.quantity || 1 };
            if (it.variation_id) out.variation_id = it.variation_id;
            return out;
        });
        var payload = { chatbot_id: H.chatbotId, conversation_id: convId, items: items };
        if (block.customer) payload.customer = block.customer;

        fetch(H.apiUrl + '/chat/payment-link', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        })
            .then(function (r) {
                return r.json().catch(function () { return {}; }).then(function (data) {
                    return { ok: r.ok, data: data };
                });
            })
            .then(function (res) {
                var orderPayUrl = res.ok && res.data && res.data.data && res.data.data.order_pay_url;
                if (orderPayUrl) {
                    btnEl.hidden = true;
                    statusEl.hidden = false;
                    statusEl.className = 'hm-payment-status';
                    // orderPayUrl lives only in this local variable and this
                    // one href attribute — never assigned anywhere else,
                    // never sent to console/localStorage/another request.
                    statusEl.innerHTML = '';
                    var payLink = document.createElement('a');
                    payLink.href = orderPayUrl;
                    payLink.target = '_blank';
                    payLink.rel = 'noopener';
                    payLink.textContent = CFG.i18n.payNowLabel;
                    statusEl.appendChild(document.createTextNode('✓ '));
                    statusEl.appendChild(payLink);
                    return;
                }
                btnEl.disabled = false;
                btnEl.textContent = originalLabel;
                statusEl.hidden = false;
                statusEl.className = 'hm-payment-status hm-payment-error';
                // Never the raw server error string here — this widget
                // never lets raw (always-English) backend error text reach
                // a customer mid-conversation in another language; one
                // translated, generic message covers every failure mode
                // (not enabled, cap exceeded, rate-limited, out of stock).
                statusEl.textContent = CFG.i18n.paymentLinkErrorLabel;
            })
            .catch(function () {
                btnEl.disabled = false;
                btnEl.textContent = originalLabel;
                statusEl.hidden = false;
                statusEl.className = 'hm-payment-status hm-payment-error';
                statusEl.textContent = CFG.i18n.paymentLinkErrorLabel;
            });
    }

    function renderProductCards(products) {
        if (!products || !products.length) return;
        var wrap = document.createElement('div');
        wrap.className = 'hm-product-cards';
        products.forEach(function (p) {
            var card = document.createElement('a');
            card.className = 'hm-product-card';
            card.href = p.product_url || '#';
            card.target = '_blank';
            card.rel = 'noopener';
            var imgHtml = p.image
                ? '<img src="' + esc(p.image) + '" alt="" loading="lazy">'
                : '<div class="hm-product-card-noimg"></div>';
            var priceHtml = (p.price !== null && typeof p.price !== 'undefined')
                ? '<span class="hm-product-price">' + esc(formatPrice(p.price, p.currency)) + '</span>' : '';
            var inStock = p.stock_status === 'instock';
            var stockHtml = p.stock_status
                ? '<span class="hm-stock-badge ' + (inStock ? 'hm-instock' : 'hm-outofstock') + '">' +
                  esc(inStock ? CFG.i18n.inStockLabel : CFG.i18n.outOfStockLabel) + '</span>' : '';
            card.innerHTML =
                imgHtml +
                '<div class="hm-product-card-body">' +
                    '<div class="hm-product-name">' + esc(p.name) + '</div>' +
                    priceHtml +
                    stockHtml +
                '</div>';
            wrap.appendChild(card);
        });
        msgs.appendChild(wrap);
    }

    function renderCompareTable(products, rows) {
        if (!products || products.length < 2) return;
        var outer = document.createElement('div');
        outer.className = 'hm-compare-wrap';
        var table = document.createElement('table');
        table.className = 'hm-compare-table';

        var theadHtml = '<thead><tr><th></th>' + products.map(function (p) {
            var imgHtml = p.image ? '<img src="' + esc(p.image) + '" alt="">' : '';
            var priceHtml = (p.price !== null && typeof p.price !== 'undefined')
                ? '<div class="hm-compare-price">' + esc(formatPrice(p.price, p.currency)) + '</div>' : '';
            var linkHtml = p.product_url
                ? '<a href="' + esc(p.product_url) + '" target="_blank" rel="noopener">' + esc(CFG.i18n.viewProductLabel) + '</a>' : '';
            return '<th>' + imgHtml + '<div class="hm-compare-name">' + esc(p.name || '') + '</div>' + priceHtml + linkHtml + '</th>';
        }).join('') + '</tr></thead>';

        var tbodyHtml = '<tbody>' + (rows || []).map(function (row) {
            return '<tr><th>' + esc(row.attribute) + '</th>' + products.map(function (p) {
                var v = row.values ? row.values[String(p.product_id)] : null;
                return '<td>' + (v === null || typeof v === 'undefined' || v === '' ? '—' : esc(v)) + '</td>';
            }).join('') + '</tr>';
        }).join('') + '</tbody>';

        table.innerHTML = theadHtml + tbodyHtml;
        outer.appendChild(table);
        msgs.appendChild(outer);
    }

    function renderHistory(list) {
        list.forEach(function (m) {
            addMsg(m.content, m.role === 'assistant' ? 'bot' : 'user');
        });
    }

    // ── Direction / language from the chatbot's own config ────────────
    function applyDirection(dir) {
        if (!dir) return;
        w.setAttribute('dir', dir);
        setThemeVars(CFG.primaryColor, dir);
    }

    // Once /chat/session responds with this chatbot's own widget_config, its
    // text/appearance wins over the get_locale()-based CFG defaults set in
    // PHP — a chatbot an admin configured for English reads English even on
    // a Persian WP site.
    function applyWidgetConfig(wc, language) {
        if (language) applyDirection(language === 'fa' ? 'rtl' : 'ltr');
        if (!wc) return;
        if (wc.send_button_label) { CFG.sendButtonLabel = wc.send_button_label; sendBtn.textContent = wc.send_button_label; }
        if (wc.input_placeholder) { CFG.placeholder = wc.input_placeholder; inp.setAttribute('placeholder', wc.input_placeholder); }
        if (wc.unavailable_message) CFG.unavailableMessage = wc.unavailable_message;
        if (wc.generic_error_message) CFG.genericErrorMessage = wc.generic_error_message;
        if (wc.connection_error_message) CFG.connectionErrorMessage = wc.connection_error_message;
        if (wc.checking_availability_message) CFG.checkingAvailabilityMessage = wc.checking_availability_message;
        if (wc.primary_color) { CFG.primaryColor = wc.primary_color; setThemeVars(wc.primary_color); }
        if (wc.position) { CFG.position = wc.position; hostEl.setAttribute('data-position', wc.position); }
        if (wc.avatar_url && wc.avatar_url !== CFG.avatarUrl) {
            CFG.avatarUrl = wc.avatar_url;
            var newAvatarHtml = avatarSlotHtml(wc.avatar_url);
            var hdrAvatar = root.getElementById('hm-avatar-hdr');
            if (hdrAvatar) hdrAvatar.innerHTML = newAvatarHtml;
            var btnAvatar = root.getElementById('hm-avatar-btn');
            if (btnAvatar) btnAvatar.innerHTML = newAvatarHtml;
        }
        if (typeof wc.powered_by_enabled !== 'undefined') CFG.poweredByEnabled = wc.powered_by_enabled;
        if (wc.powered_by_name) CFG.poweredByName = wc.powered_by_name;
        if (wc.powered_by_url) CFG.poweredByUrl = wc.powered_by_url;
        // An admin-uploaded mark (Settings > Brand, platform-wide — not
        // per-chatbot) replaces the built-in silhouette everywhere it's
        // used: the footer badge below, and — since no avatar_url means
        // avatarSlotHtml() falls back to markMono() too — the header and
        // floating-toggle badges, refreshed the same way avatar_url already
        // is above.
        var markChanged = false;
        if (wc.powered_by_mark_url && wc.powered_by_mark_url !== CFG.poweredByMarkUrl) {
            CFG.poweredByMarkUrl = wc.powered_by_mark_url;
            markChanged = true;
        }
        if (wc.powered_by_mark_light_url && wc.powered_by_mark_light_url !== CFG.poweredByMarkLightUrl) {
            CFG.poweredByMarkLightUrl = wc.powered_by_mark_light_url;
            markChanged = true;
        }
        if (markChanged && !CFG.avatarUrl) {
            var freshMono = avatarSlotHtml(CFG.avatarUrl);
            var hdrAvatar2 = root.getElementById('hm-avatar-hdr');
            if (hdrAvatar2) hdrAvatar2.innerHTML = freshMono;
            var btnAvatar2 = root.getElementById('hm-avatar-btn');
            if (btnAvatar2) btnAvatar2.innerHTML = freshMono;
        }
        renderPoweredBy();

        // chat_title/ai_name/quick_questions: the server (customer portal)
        // is the source of truth for these now — the PHP-side CFG values
        // (from WordPress's own local options) are only a first-paint
        // fallback before this response exists. A merchant changing these
        // in the portal must see the new text with zero WordPress-side
        // changes, exactly like welcome_message already does.
        if (wc.chat_title) {
            CFG.chatTitle = wc.chat_title;
            var titleEl = root.querySelector('#hm-hdr h3');
            if (titleEl) titleEl.textContent = wc.chat_title;
        }
        if (wc.ai_name) {
            CFG.aiName = wc.ai_name;
            var nameEl = root.querySelector('#hm-hdr span');
            if (nameEl) nameEl.textContent = wc.ai_name;
        }
        if (wc.quick_questions) {
            CFG.quickQuestions = wc.quick_questions;
            renderQuickQuestions();
        }
    }

    function renderQuickQuestions() {
        var list = CFG.quickQuestions || [];
        if (!list.length) {
            if (qqBox) qqBox.remove();
            qqBox = null;
            return;
        }
        var html = list.map(function (q, i) {
            return '<button type="button" data-i="' + i + '">' + esc(q.question) + '</button>';
        }).join('');
        if (!qqBox) {
            qqBox = document.createElement('div');
            qqBox.id = 'hm-qq';
            bindQuickQuestionClicks(qqBox);
            msgs.insertAdjacentElement('afterend', qqBox);
        }
        qqBox.innerHTML = html;
    }

    function loadHistory(id) {
        return fetch(H.apiUrl + '/chat/conversation/' + encodeURIComponent(id) + '/messages?chatbot_id=' + encodeURIComponent(H.chatbotId))
            .then(function (r) { return r.ok ? r.json() : { data: { messages: [] } }; })
            .then(function (d) { return (d.data && d.data.messages) || []; })
            .catch(function () { return []; });
    }

    function init() {
        sessionInitStarted = true;
        fetch(H.apiUrl + '/chat/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            // This request never carried a language at all, so the server's
            // own default ('en' — see ChatController::createSession())
            // always won, and that same value echoes straight back as
            // d.language below, which applyWidgetConfig() uses to force
            // dir — overwriting the correct rtl this page already set from
            // CFG.dir moments earlier. On every Persian site, every single
            // new conversation: starts rtl, flips to ltr a moment after
            // /chat/session responds. CFG.dir is the one thing already
            // known for certain at this point (get_locale() on a
            // server-rendered page, not a guess), so it is also the
            // correct source for what to tell the server here.
            // (CFG.dir is the chatbot's own last-known language when one is
            // remembered — see loadCachedConfig() — else the WP locale.)
            body: JSON.stringify({ chatbot_id: H.chatbotId, session_id: H.sessionId, page_url: window.location.href, language: CFG.dir === 'rtl' ? 'fa' : 'en' }),
        })
            .then(function (r) { if (!r.ok) throw new Error('unavailable'); return r.json(); })
            .then(function (data) {
                var d = data.data || {};
                convId = d.conversation_id;
                persistConv(H.sessionId, convId);
                applyWidgetConfig(d.widget_config, d.language);
                cacheConfig(d.language, d.widget_config);

                var reusedExisting = persistedConvId && persistedConvId === convId;
                if (reusedExisting && !historyLoaded) {
                    historyLoaded = true;
                    loadHistory(convId).then(function (list) {
                        if (list.length) {
                            renderHistory(list);
                        } else if (d.welcome_message) {
                            addMsg(d.welcome_message, 'bot');
                        }
                    });
                } else if (d.welcome_message) {
                    addMsg(d.welcome_message, 'bot');
                }
            })
            .catch(function () { unavailable = true; addMsg(CFG.unavailableMessage, 'bot'); });
    }

    // Streaming is opt-in via the Accept header, on a per-browser-capability
    // basis (fetch + ReadableStream both needed to actually read a stream).
    // If the browser can't stream, we never send that header at all, so the
    // backend never even attempts SSE for that request — ChatController::
    // sendMessage() only branches into streaming on the literal
    // "text/event-stream" string, so this degrades to the exact same JSON
    // response every older/legacy client already gets.
    var canStream = typeof fetch !== 'undefined' && typeof ReadableStream !== 'undefined' && typeof TextDecoder !== 'undefined';

    function send(text) {
        var t = (typeof text === 'string' ? text : inp.value).trim();
        if (!t || !convId) return;
        if (typeof text !== 'string') inp.value = '';
        autoResize();
        addMsg(t, 'user');
        sendBtn.disabled = true;
        showTyping();

        fetch(H.apiUrl + '/chat/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': canStream ? 'text/event-stream' : 'application/json',
            },
            body: JSON.stringify({ chatbot_id: H.chatbotId, conversation_id: convId, message: t, session_id: H.sessionId }),
        })
            .then(function (r) {
                var contentType = (r.headers.get('Content-Type') || '');
                if (canStream && contentType.indexOf('text/event-stream') !== -1 && r.body) {
                    return handleStreamResponse(r);
                }
                return r.json().then(function (data) { return { ok: r.ok, data: data }; }).then(handleJsonResponse);
            })
            .catch(function () { sendBtn.disabled = false; hideTyping(); addMsg(CFG.connectionErrorMessage, 'bot'); });
    }

    function handleJsonResponse(res) {
        sendBtn.disabled = false;
        hideTyping();
        if (!res.ok) { addMsg(res.data && res.data.error ? res.data.error : CFG.genericErrorMessage, 'bot'); return; }
        var d = res.data.data;
        var hasBlocks = d && d.widget_blocks && d.widget_blocks.length;
        if (d && d.response) addMsg(d.response, 'bot');
        // A 200 OK with an empty response and no widget_blocks (a bad-but-
        // "successful" upstream call, or a grounding guard that stripped a
        // reply to nothing) must never just close the typing indicator and
        // show the customer literally nothing — see the equivalent guard on
        // the streaming path's 'done' handler below.
        else if (!hasBlocks) { addMsg(CFG.genericErrorMessage, 'bot'); }
        if (d) renderWidgetBlocks(d.widget_blocks);
    }

    // Reads the SSE body as it arrives, growing one bot bubble token-by-token
    // instead of waiting for the whole reply. Falls back to a plain error
    // message if the stream ends having sent zero content (the server always
    // emits at least the configured fallback text as a delta on failure, so
    // this really only guards a truly dead/cut connection).
    function handleStreamResponse(r) {
        var reader = r.body.getReader();
        var decoder = new TextDecoder();
        var buffer = '';
        var bubble = null;
        var fullText = '';
        var realContentArrived = false;

        function processFrame(frame) {
            var eventName = 'message';
            var dataLines = [];
            frame.split('\n').forEach(function (line) {
                if (line.indexOf('event:') === 0) eventName = line.slice(6).trim();
                else if (line.indexOf('data:') === 0) dataLines.push(line.slice(5).replace(/^ /, ''));
            });
            if (!dataLines.length) return;
            var data;
            try { data = JSON.parse(dataLines.join('\n')); } catch (e) { return; }

            if (eventName === 'error') {
                sendBtn.disabled = false;
                hideTyping();
                if (!bubble) addMsg(CFG.genericErrorMessage, 'bot');
                return;
            }
            if (eventName === 'interim') {
                // A real, server-decided placeholder (see rag_service.
                // run_rag_pipeline_stream()) sent right after intent
                // classification, before the genuinely slow part of a
                // tool-calling turn even starts. `fullText` deliberately
                // stays '' here — the first REAL delta's own fullText+=/
                // updateBotBubble() call below then overwrites this
                // placeholder outright, never appends after it.
                if (!bubble) { hideTyping(); bubble = addMsg(data.text || '', 'bot'); }
                return;
            }
            if (eventName === 'done') {
                sendBtn.disabled = false;
                var hadBlocks = data.widget_blocks && data.widget_blocks.length;
                // Same gap the non-streaming handleJsonResponse() had: a
                // well-formed 'done' event carrying zero real deltas the
                // whole stream and no widget_blocks is a legitimate "server
                // said 200/done" outcome, not the dead-connection case
                // pump()'s own guard below already covers — so it needs the
                // identical fallback here. Covers the bubble-already-exists
                // case too (an interim placeholder that nothing ever
                // replaced, because the turn ended up with zero real
                // content) — a stuck placeholder would otherwise look like
                // a real, final answer.
                if (!realContentArrived && !hadBlocks) {
                    hideTyping();
                    if (bubble) updateBotBubble(bubble, CFG.genericErrorMessage);
                    else bubble = addMsg(CFG.genericErrorMessage, 'bot');
                    realContentArrived = true; // settled — pump()'s own closing check must not re-fire this.
                }
                renderWidgetBlocks(data.widget_blocks);
                return;
            }
            if (data.delta) {
                if (!bubble) { hideTyping(); bubble = addMsg('', 'bot'); }
                realContentArrived = true;
                // fullText is still '' the first time this runs, whether or
                // not an interim placeholder was shown first (that path
                // never touches it) — so this always correctly starts the
                // real answer fresh, replacing any placeholder text that
                // was showing rather than appending after it.
                fullText += data.delta;
                updateBotBubble(bubble, fullText);
            }
        }

        function pump() {
            return reader.read().then(function (result) {
                if (result.done) {
                    sendBtn.disabled = false;
                    hideTyping();
                    // Covers an interim-only bubble too (connection dropped
                    // right after the placeholder, before any real content
                    // or a 'done' event) — same reasoning as the 'done'
                    // handler above.
                    if (!realContentArrived) {
                        if (bubble) updateBotBubble(bubble, CFG.genericErrorMessage);
                        else addMsg(CFG.genericErrorMessage, 'bot');
                    }
                    return;
                }
                buffer += decoder.decode(result.value, { stream: true });
                var idx;
                while ((idx = buffer.indexOf('\n\n')) !== -1) {
                    processFrame(buffer.slice(0, idx));
                    buffer = buffer.slice(idx + 2);
                }
                return pump();
            });
        }

        return pump();
    }

    function bindQuickQuestionClicks(el) {
        el.addEventListener('click', function (e) {
            var btn = e.target.closest('button[data-i]');
            if (!btn) return;
            var q = CFG.quickQuestions[parseInt(btn.getAttribute('data-i'), 10)];
            if (!q) return;
            // Sent through the exact same path as a hand-typed message (not
            // answered instantly client-side) so it's recorded server-side
            // and shows up in analytics/token accounting like any other
            // message.
            send(q.question);
        });
    }
    if (qqBox) bindQuickQuestionClicks(qqBox);

    // ── Textarea auto-grow (up to 4 lines) ────────────────────────────
    function autoResize() {
        inp.style.height = 'auto';
        var lineHeight = parseFloat(getComputedStyle(inp).lineHeight) || 20;
        var maxHeight = lineHeight * 4 + 20;
        inp.style.height = Math.min(inp.scrollHeight, maxHeight) + 'px';
    }
    inp.addEventListener('input', autoResize);

    // ── Mobile keyboard handling via visualViewport ───────────────────
    function isMobileViewport() {
        return window.matchMedia('(max-width: 480px)').matches;
    }
    function handleViewportResize() {
        if (!window.visualViewport || !isMobileViewport() || !isOpen) return;
        var vv = window.visualViewport;
        box.style.height = vv.height + 'px';
        box.style.top = vv.offsetTop + 'px';
        scrollToBottom(false);
    }
    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', handleViewportResize);
        window.visualViewport.addEventListener('scroll', handleViewportResize);
    }

    // ── Modal on mobile, not on desktop ────────────────────────────────
    // On a desktop the open panel floats beside the page and the page stays
    // usable, so it is a non-modal dialog: no focus trap (trapping focus in
    // something that does not block the page is itself an accessibility
    // bug). Below 480px it covers the whole viewport and the page behind
    // cannot be used, so there it IS modal: aria-modal="true" and Tab /
    // Shift+Tab wrap inside the panel. Re-evaluated on open and on resize
    // (rotating a phone, resizing a window).
    function syncModal() {
        box.setAttribute('aria-modal', isOpen && isMobileViewport() ? 'true' : 'false');
    }
    function focusables() {
        return Array.prototype.filter.call(
            box.querySelectorAll('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])'),
            function (el) { return !el.disabled && !el.hidden && el.getAttribute('aria-hidden') !== 'true'; }
        );
    }
    box.addEventListener('keydown', function (e) {
        if (e.key !== 'Tab' || box.getAttribute('aria-modal') !== 'true') return;
        var list = focusables();
        if (!list.length) return;
        var first = list[0], last = list[list.length - 1];
        var active = root.activeElement;
        if (e.shiftKey && (active === first || !box.contains(active))) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && (active === last || !box.contains(active))) { e.preventDefault(); first.focus(); }
    });
    window.addEventListener('resize', syncModal);

    var bodyOverflowBackup = null;
    function lockBodyScroll(lock) {
        if (!isMobileViewport()) return;
        if (lock) {
            bodyOverflowBackup = document.body.style.overflow;
            document.body.style.overflow = 'hidden';
        } else if (bodyOverflowBackup !== null) {
            document.body.style.overflow = bodyOverflowBackup;
            bodyOverflowBackup = null;
        }
    }

    // ── Open / close, with focus management + Escape-to-close ─────────
    var lastFocused = null;
    function openWidget() {
        isOpen = true;
        persistOpen(true);
        box.classList.add('hm-open');
        box.setAttribute('aria-hidden', 'false');
        w.classList.add('hm-mobile-open');
        // Also on the shadow *host* itself, not just the inner #hm-w — the
        // mobile full-viewport :host(.hm-mobile-open) rule in
        // haman-widget.css keys off this class directly on the host so the
        // full-screen override only applies while actually open. Without
        // it, the invisible host div would cover (and click-block) the
        // entire page any time the viewport is narrow, even closed.
        hostEl.classList.add('hm-mobile-open');
        openBtn.setAttribute('aria-expanded', 'true');
        unreadDot.classList.remove('hm-visible');
        lockBodyScroll(true);
        syncModal();
        // Focus inside the widget reads as the shadow *host* from the
        // document — a plain div, not focusable — so opening from the
        // launcher used to "restore" focus onto nothing on close. Remember
        // the real element inside the shadow root instead.
        lastFocused = document.activeElement === hostEl ? (root.activeElement || openBtn) : document.activeElement;
        if (!sessionInitStarted && !unavailable) init();
        setTimeout(function () { inp.focus(); handleViewportResize(); }, 0);
    }
    function closeWidget() {
        isOpen = false;
        persistOpen(false);
        box.classList.remove('hm-open');
        box.setAttribute('aria-hidden', 'true');
        w.classList.remove('hm-mobile-open');
        hostEl.classList.remove('hm-mobile-open');
        openBtn.setAttribute('aria-expanded', 'false');
        lockBodyScroll(false);
        syncModal();
        box.style.height = '';
        box.style.top = '';
        if (lastFocused && lastFocused.focus) lastFocused.focus();
        else openBtn.focus();
    }
    function toggle() { isOpen ? closeWidget() : openWidget(); }

    openBtn.addEventListener('click', toggle);
    closeBtn.addEventListener('click', toggle);
    sendBtn.addEventListener('click', function () { send(); });
    inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && isOpen) closeWidget();
    });

    // The remembered config, before anything is painted: same function the
    // live /chat/session answer goes through, so it can only set what the
    // server itself sent last time.
    if (cachedConfig) applyWidgetConfig(cachedConfig.wc, cachedConfig.language);

    if (loadPersistedOpen()) openWidget();
})();
