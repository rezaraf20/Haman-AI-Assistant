<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Haman_Product_Sync {
    // See Haman_Page_Sync::MAX_BATCH_BYTES — batches sized by byte length, not
    // item count, to stay under the host's ~128KB WAF request-body limit.
    const MAX_BATCH_BYTES = 80000;
    const FETCH_PAGE_SIZE = 50;

    // "Is this genuine?" — the single most common question across both real
    // customer interviews this was built from (electronics parts AND
    // cosmetics). MUST be a data field the seller actually entered, never
    // something the model infers — see the admin-configured mapping this
    // reads from (Sync tab, haman_field_mapping option) and
    // authenticity_fields() below. Shared with class-haman-admin.php's
    // settings form so both sides list the exact same 5 fields.
    const AUTHENTICITY_FIELDS = [
        'authenticity_status', 'brand', 'official_distributor',
        'warranty_period', 'country_of_origin',
    ];

    public function __construct( private Haman_Api_Client $api ) {}

    /**
     * A real store (khonehrangi.ir) proved this necessary: sync_all()'s
     * first page is the exact same query -- status=publish, limit=50,
     * page=1 -- on every single run, forever. A store with a persistent
     * object cache (Redis, Memcached, ...) caches WooCommerce's product
     * query results keyed by exactly those arguments, and WooCommerce only
     * busts that cache on a product create/update/delete -- never because
     * "a while has passed" or "an admin asked for a full resync". One
     * measurement: khonehrangi.ir's wc_get_products() returned only 6
     * products through this call while the SAME site's own Store API
     * (wp-json/wc/store/v1/products, a different code path with different
     * query args) correctly reported 173 -- proof the catalogue was fine
     * and this one query shape was the one being served a stale answer.
     * bump_query_version() forces WooCommerce to treat every cached
     * product-query transient as expired before the loop below runs a
     * single query, which is the mechanism WooCommerce itself uses
     * in wc_delete_product_transients() -- this borrows that, rather than
     * reaching for a raw cache-flush this plugin has no business doing on
     * a customer's site.
     */
    private function bump_query_version(): void {
        if (class_exists('WC_Cache_Helper')) {
            WC_Cache_Helper::get_transient_version('product_query', true);
        }
    }

    public function sync_all( string $cid ): array {
        // Same shape as every other empty/not-applicable result (see
        // Haman_Faq_Sync::sync_all()'s own comment on exactly this) — a
        // bare ['skipped' => 'WooCommerce not active'] used to reach the
        // admin results table directly as $row, and settings-page.php's
        // table cell (esc_html($row['skipped'] ?? 0)) printed that string
        // raw into what every other row shows as a plain count, with
        // 'new'/'updated'/'deleted'/'failed' silently missing from the
        // row entirely. The real explanation now travels separately, in
        // 'note', which the table ignores and the notice block below it
        // renders instead.
        if (!class_exists('WooCommerce')) {
            return array_merge(Haman_Sync_Counts::empty(), [
                'note' => 'محصولات همگام نشدند چون ووکامرس روی این سایت فعال نیست. / Products were not synced because WooCommerce is not active on this site.',
            ]);
        }
        $this->bump_query_version();
        $page=1; $counts=Haman_Sync_Counts::empty(); $errors=[]; $batch=[]; $batchBytes=0;
        do {
            $products = wc_get_products(['status'=>'publish','limit'=>self::FETCH_PAGE_SIZE,'page'=>$page,'return'=>'objects','cache_results'=>false]);
            foreach ($products as $product) {
                $item     = $this->product_to_array($product);
                $itemSize = strlen(wp_json_encode($item));
                if (!empty($batch) && ($batchBytes + $itemSize) > self::MAX_BATCH_BYTES) {
                    $this->flush_batch($cid, $batch, $counts, $errors);
                    $batch = []; $batchBytes = 0;
                }
                $batch[]     = $item;
                $batchBytes += $itemSize;
            }
            $page++;
        } while (count($products) === self::FETCH_PAGE_SIZE);
        $this->flush_batch($cid, $batch, $counts, $errors);
        $result = $counts;
        if (!empty($errors)) $result['errors'] = array_values(array_unique($errors));
        return $result;
    }

    /**
     * Sums whatever new/updated/skipped/deleted/failed counts the platform
     * actually computed for this batch (SyncJob.result, now returned in the
     * API response — see SyncController::jobArr()) instead of just counting
     * how many items this batch attempted to push. A full sync may flush
     * several batches, each its own SyncJob, so these accumulate across
     * calls into sync_all()'s final total — which is exactly what the
     * admin's results table (settings-page.php) reads.
     */
    private function flush_batch( string $cid, array $batch, array &$counts, array &$errors ): void {
        if (empty($batch)) return;
        $r = $this->api->sync_products($cid, $batch);
        if (is_wp_error($r)) { $errors[] = $r->get_error_message(); return; }
        Haman_Sync_Counts::add($counts, is_array($r) ? ($r['result'] ?? []) : []);
    }

    public function sync_recent( string $cid, int $hours=25 ): void {
        if (!class_exists('WooCommerce')) return;
        $products = wc_get_products(['status'=>'publish','limit'=>self::FETCH_PAGE_SIZE,'date_modified'=>'>'.date('Y-m-d H:i:s',strtotime("-{$hours} hours")),'cache_results'=>false]);
        if (empty($products)) return;
        $counts = Haman_Sync_Counts::empty(); $errors = [];
        $this->flush_batch($cid, array_map([$this,'product_to_array'],$products), $counts, $errors);
    }

    public function product_to_array( \WC_Product $p ): array {
        $cats = [];
        foreach ($p->get_category_ids() as $cid) {
            $term = get_term($cid,'product_cat');
            if ($term && !is_wp_error($term)) $cats[] = ['id'=>$term->term_id,'name'=>$term->name];
        }
        $base = [
            'id'=>$p->get_id(),'name'=>$p->get_name(),'slug'=>$p->get_slug(),'sku'=>$p->get_sku(),
            'type'=>$p->get_type(),'status'=>$p->get_status(),
            'description'=>wp_strip_all_tags($p->get_description()),
            'short_description'=>wp_strip_all_tags($p->get_short_description()),
            'price'=>(float)$p->get_price(),'regular_price'=>(float)$p->get_regular_price(),
            'sale_price'=>(float)$p->get_sale_price(),'currency'=>get_woocommerce_currency(),
            'stock_status'=>$p->get_stock_status(),'stock_quantity'=>$p->get_stock_quantity(),
            'average_rating'=>(float)$p->get_average_rating(),'review_count'=>$p->get_review_count(),
            'permalink' => get_site_url() . '/?p=' . $p->get_id(),
            'featured_image'=>get_the_post_thumbnail_url($p->get_id(),'medium')?:null,
            'categories'=>$cats,
            'tags'=>wp_get_post_terms($p->get_id(),'product_tag',['fields'=>'names']),
            'attachments'=>$this->product_pdf_attachments($p),
        ];
        return array_merge( $base, $this->authenticity_fields( $p ) );
    }

    /**
     * "Is this genuine?" — real, seller-entered data only, never something
     * the model infers from a description or reviews (see rag_service.
     * _authenticity_rule() on the Python side, which enforces this at
     * answer time too). Every store names its custom fields differently, so
     * this reads from the admin-configured mapping (Sync tab,
     * haman_field_mapping option: field => {type: 'meta'|'attribute', key})
     * rather than guessing a field name — a semantic field with no mapping,
     * or whose mapped source is empty for this specific product, comes back
     * null, never a guess pulled from an unrelated field.
     */
    private function authenticity_fields( \WC_Product $p ): array {
        $mapping = get_option( 'haman_field_mapping', [] );
        if ( ! is_array( $mapping ) ) $mapping = [];

        $out = [];
        foreach ( self::AUTHENTICITY_FIELDS as $field ) {
            $out[ $field ] = $this->read_mapped_field( $p, is_array( $mapping[ $field ] ?? null ) ? $mapping[ $field ] : null );
        }
        return $out;
    }

    private function read_mapped_field( \WC_Product $p, ?array $conf ): ?string {
        if ( ! $conf || empty( $conf['key'] ) ) return null;
        $key  = (string) $conf['key'];
        $type = $conf['type'] ?? '';

        if ( 'meta' === $type ) {
            $value = get_post_meta( $p->get_id(), $key, true );
            $value = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
        } elseif ( 'attribute' === $type ) {
            $value = $this->read_attribute_value( $p, $key );
        } else {
            return null;
        }

        $value = trim( wp_strip_all_tags( $value ) );
        return '' !== $value ? $value : null;
    }

    private function read_attribute_value( \WC_Product $p, string $attribute_name ): string {
        $attributes = $p->get_attributes();
        if ( ! isset( $attributes[ $attribute_name ] ) ) return '';
        $attribute = $attributes[ $attribute_name ];
        if ( $attribute->is_taxonomy() ) {
            $terms = wc_get_product_terms( $p->get_id(), $attribute->get_name(), [ 'fields' => 'names' ] );
            return implode( ', ', $terms );
        }
        return implode( ', ', $attribute->get_options() );
    }

    /**
     * The shop's most expensive question type, per the interview this
     * traces back to, comes from a datasheet — but a datasheet is rarely
     * "the product description," it's a PDF sitting either as a WordPress
     * media attachment on the product post, or just linked from inside the
     * description HTML. wp_strip_all_tags() (used above for the text
     * fields) already discarded those href attributes, so this scans the
     * *raw* description/short_description before that stripping happens.
     * Deduplicated by URL — the same file linked in text and also attached
     * as media must only be synced once.
     */
    private function product_pdf_attachments( \WC_Product $p ): array {
        if ( get_option( 'haman_sync_pdfs', '1' ) !== '1' ) return [];

        $found = []; // url => name

        foreach ( get_attached_media( 'application/pdf', $p->get_id() ) as $attachment ) {
            $url = wp_get_attachment_url( $attachment->ID );
            if ( $url ) $found[ $url ] = $attachment->post_title ?: basename( $url );
        }

        $raw_html = $p->get_description() . ' ' . $p->get_short_description();
        if ( preg_match_all( '/href=["\']([^"\']+\.pdf)(?:[?#][^"\']*)?["\']/i', $raw_html, $matches ) ) {
            foreach ( $matches[1] as $url ) {
                if ( ! isset( $found[ $url ] ) ) $found[ $url ] = basename( parse_url( $url, PHP_URL_PATH ) ?: $url );
            }
        }

        $attachments = [];
        foreach ( $found as $url => $name ) {
            $attachments[] = [ 'url' => $url, 'name' => $name ];
        }
        return $attachments;
    }
}
